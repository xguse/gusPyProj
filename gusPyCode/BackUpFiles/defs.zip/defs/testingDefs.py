

def countMotif(motifStr, seqList):
    #  Compile RegEx obj from motifStr