import string
import JamesDefs




#========================= User Defined Variables =========================

# File paths:

# IN:
codingBoundsList       = open('/Users/biggus/Documents/MBGB/Rotations/James/Data/Sequence/Aedes/aedesProcessed/aedesCodingBoundsOut.txt','r').readlines()
resolvedConflictsList  = open('/Users/biggus/Documents/MBGB/Rotations/James/Data/Sequence/Aedes/aedesProcessed/aedesBounds.Both.fjoinResolved.txt','r').readlines()

# OUT:
reCombinedCoordsFILE   = open('/Users/biggus/Documents/MBGB/Rotations/James/Data/Sequence/Aedes/aedesProcessed/aedesListOfUsableUpStrmBdryCoords.txt','w')


shortestUsableBdryReg  = 10

#==========================================================================

#--------- Script Specific Function Definitions ---------------------

def mergeListUnless(codingBoundsList, resolvedConflictsList, unUsableGeneNames, namesInResolvedConflictsList):
    
    for rec in codingBoundsList:
        
        #  If rec's name is in unUsable list or resolved list already move to next rec
        if rec[0] in unUsableGeneNames:
            continue
        elif rec[0] in namesInResolvedConflictsList:
            continue
        
        if rec[3] in ['1','+']:
            resolvedConflictsList.append([rec[0], rec[1], rec[3], rec[8], rec[9], str(int(rec[9]) - int(rec[8]) + 1)])
        elif rec[3] in ['-1','-']:
            resolvedConflictsList.append([rec[0], rec[1], rec[3], rec[10], rec[11], str(int(rec[11]) - int(rec[10]) + 1)])
        


# Strip trailing newlines
codingBoundsList = map(string.strip, codingBoundsList)
resolvedConflictsList = map(string.strip, resolvedConflictsList)
                            

# Convert these into lists of lists so that field vals can be interrogated and copied 
# Explode tab delimited strings of each record into list of values
JamesDefs.explodeDelimitedList(codingBoundsList, '\t')
JamesDefs.explodeDelimitedList(resolvedConflictsList, '\t')


len_codingBoundsList = len(codingBoundsList)
len_resolvedConflictsList = len(resolvedConflictsList)



# Populate unUsableList
unUsableGeneNames = []
i = 0
while i < len_resolvedConflictsList:
    
    if int(resolvedConflictsList[i][5]) < shortestUsableBdryReg:
        unUseableGene = resolvedConflictsList.pop(i)
        unUsableGeneNames.append(unUseableGene[0])
        unUseableGene = None
 
        #!!! when you pop _DO_NOT_ advance i and _DO_ reduce len_resolvedConflictsList to reflect new length
        len_resolvedConflictsList = len_resolvedConflictsList - 1 
    else:
        i=i+1
        

#  Create list of gene names still in resolvedConflictsList    
namesInResolvedConflictsList = []
for every in resolvedConflictsList:
    namesInResolvedConflictsList.append(every[0])
        
#  Append full boundary region records to resolved list unless name is in unUsableGeneNames
mergeListUnless(codingBoundsList, resolvedConflictsList, unUsableGeneNames, namesInResolvedConflictsList)


for each in resolvedConflictsList:
    reCombinedCoordsFILE.write('\t'.join(each)+'\n')


print 'Yay'

        
        
        
        
        
